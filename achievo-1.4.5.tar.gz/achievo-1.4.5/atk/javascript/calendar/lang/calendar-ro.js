// ** I18N
Calendar._DN = new Array
("Duminic�",
 "Luni",
 "Mar�i",
 "Miercuri",
 "Joi",
 "Vineri",
 "S�mb�t�",
 "Duminic�");
Calendar._MN = new Array
("Ianuarie",
 "Februarie",
 "Martie",
 "Aprilie",
 "Mai",
 "Iunie",
 "Iulie",
 "August",
 "Septembrie",
 "Octombrie",
 "Noiembrie",
 "Decembrie");

// tooltips
Calendar._TT = {};
Calendar._TT["TOGGLE"] = "Schimb� prima zi din s�pt�m�n�";
Calendar._TT["PREV_YEAR"] = "Anul precedent (lung pt menu)";
Calendar._TT["PREV_MONTH"] = "Luna precedent� (lung pt menu)";
Calendar._TT["GO_TODAY"] = "Data de azi";
Calendar._TT["NEXT_MONTH"] = "Luna urm�toare (lung pt menu)";
Calendar._TT["NEXT_YEAR"] = "Anul urm�tor (lung pt menu)";
Calendar._TT["SEL_DATE"] = "Selecteaz� data";
Calendar._TT["DRAG_TO_MOVE"] = "Trage pentru a mi�ca";
Calendar._TT["PART_TODAY"] = " (ast�zi)";
Calendar._TT["MON_FIRST"] = "Prima zi -> Luni";
Calendar._TT["SUN_FIRST"] = "Prima zi -> Duminic�";
Calendar._TT["CLOSE"] = "�nchide";
Calendar._TT["TODAY"] = "Ast�zi";

// date formats
Calendar._TT["DEF_DATE_FORMAT"] = "dd-mm-y";
Calendar._TT["TT_DATE_FORMAT"] = "D, d M";

Calendar._TT["WK"] = "wk";
