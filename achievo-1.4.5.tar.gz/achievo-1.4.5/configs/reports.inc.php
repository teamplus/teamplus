<?php

// Hide parameters of the report
// This only works for reports that are based on the basereport
$config['report_hide_parameters']=false;

//path to filename util (hourssurvay report) - its must generate csv file name
$config['filename'] = '';

?>