<?php

  // make the 'contactperson' field a relation instead of a textfield:
  $config['contact_is_relation'] = false;

  // Add project after quotation is accepted
  $config['quotation_addproject'] = true;

  $config['quotation_dir'] = "./documents/quotation/";
  
  $config['doctemplatedir']="doctemplates/";
  

?>